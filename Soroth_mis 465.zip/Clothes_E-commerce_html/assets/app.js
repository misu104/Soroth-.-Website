
const SOROTH_PRODUCTS = [
  {
    "id": "SR101",
    "name": "Emerald Heritage Gown",
    "price": 11500,
    "stock": 8,
    "category": "evening",
    "gender": "Women",
    "image": "Image/soroth_green_gown.jpg",
    "description": "Embroidered flowing gown with statement border and matching drape.",
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "badge": "New"
  },
  {
    "id": "SR102",
    "name": "Bangla Crest Polo",
    "price": 1850,
    "stock": 18,
    "category": "summer",
    "gender": "Men",
    "image": "Image/soroth_mens_polo.jpg",
    "description": "Smart cotton polo with contrast collar and signature chest crest.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Best Seller"
  },
  {
    "id": "SR103",
    "name": "Skyline Stripe Dress",
    "price": 3200,
    "stock": 11,
    "category": "summer",
    "gender": "Women",
    "image": "Image/soroth_striped_dress.jpg",
    "description": "Easy striped day dress with tie waist and breezy fit.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Fresh Drop"
  },
  {
    "id": "SR104",
    "name": "Cloud Essential Hoodie",
    "price": 2600,
    "stock": 14,
    "category": "winter",
    "gender": "Men",
    "image": "Image/soroth_hoodie.avif",
    "description": "Soft fleece hoodie made for daily layering and clean streetwear looks.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Core"
  },
  {
    "id": "SR105",
    "name": "Pureline Black Tee",
    "price": 950,
    "stock": 22,
    "category": "discount",
    "gender": "Men",
    "image": "Image/soroth_black_tshirt.jpg",
    "description": "Minimal everyday tee with premium feel and clean silhouette.",
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "badge": "Save 15%"
  },
  {
    "id": "SR106",
    "name": "Resort Linen Shirt",
    "price": 2100,
    "stock": 15,
    "category": "summer",
    "gender": "Men",
    "image": "Image/Linen Button-Up.webp",
    "description": "Relaxed linen shirt for warm-weather comfort and refined style.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Season Pick"
  },
  {
    "id": "SR107",
    "name": "Signature Blazer Set",
    "price": 6900,
    "stock": 6,
    "category": "evening",
    "gender": "Women",
    "image": "Image/Formal Blazer Set.webp",
    "description": "Tailored blazer set with polished finish for events and power dressing.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Premium"
  },
  {
    "id": "SR108",
    "name": "Sunlit Midi Dress",
    "price": 3400,
    "stock": 12,
    "category": "summer",
    "gender": "Women",
    "image": "Image/Summer Midi Dress.webp",
    "description": "Light midi dress crafted for brunches, travel, and all-day comfort.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Popular"
  },
  {
    "id": "SR109",
    "name": "Classic Wrap Dress",
    "price": 3800,
    "stock": 9,
    "category": "summer",
    "gender": "Women",
    "image": "Image/Wrap Dress.webp",
    "description": "Flattering wrap silhouette with movement and easy elegance.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Trending"
  },
  {
    "id": "SR110",
    "name": "Alpine Wool Coat",
    "price": 7900,
    "stock": 5,
    "category": "winter",
    "gender": "Women",
    "image": "Image/Wool Coat.webp",
    "description": "Structured winter coat with luxe warmth and timeless character.",
    "sizes": [
      "M",
      "L"
    ],
    "badge": "Limited"
  },
  {
    "id": "SR111",
    "name": "Cashmere Ease Sweater",
    "price": 4300,
    "stock": 10,
    "category": "winter",
    "gender": "Women",
    "image": "Image/Cashmere Sweater.webp",
    "description": "Soft knit sweater designed for elevated cold-weather layering.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Soft Touch"
  },
  {
    "id": "SR112",
    "name": "Leather Handbag Edit",
    "price": 4800,
    "stock": 7,
    "category": "evening",
    "gender": "Women",
    "image": "Image/Leather Handbag Collection.webp",
    "description": "Statement handbag collection with clean structure and rich texture.",
    "sizes": [
      "One Size"
    ],
    "badge": "Luxury"
  },
  {
    "id": "SR113",
    "name": "Scarlet Edge Heels",
    "price": 4100,
    "stock": 8,
    "category": "evening",
    "gender": "Women",
    "image": "Image/Designer Heels.webp",
    "description": "Sharp finishing heels built for parties, dinners, and occasion wear.",
    "sizes": [
      "37",
      "38",
      "39",
      "40"
    ],
    "badge": "Style Pick"
  },
  {
    "id": "SR114",
    "name": "Essential Cotton Shirt",
    "price": 1750,
    "stock": 16,
    "category": "discount",
    "gender": "Men",
    "image": "Image/Premium Cotton Shirt.jpg",
    "description": "Smart everyday shirt with clean finish and breathable cotton feel.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Save 10%"
  },
  {
    "id": "SR115",
    "name": "Urban Denim Jacket",
    "price": 3600,
    "stock": 9,
    "category": "winter",
    "gender": "Men",
    "image": "Image/Denim Jacket.jpg",
    "description": "Layer-ready denim jacket with confident silhouette and durable feel.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Streetwear"
  },
  {
    "id": "SR116",
    "name": "Midnight Velvet Gown",
    "price": 12800,
    "stock": 4,
    "category": "evening",
    "gender": "Women",
    "image": "Image/Midnight Velvet Gown.jpg",
    "description": "Luxury evening gown with rich drape and formal-event presence.",
    "sizes": [
      "S",
      "M",
      "L"
    ],
    "badge": "Exclusive"
  },
  {
    "id": "SR117",
    "name": "Puffer Weekend Jacket",
    "price": 5200,
    "stock": 6,
    "category": "winter",
    "gender": "Men",
    "image": "Image/Puffer Jacket.webp",
    "description": "Comfort-first padded outerwear for cooler days and daily travel.",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "badge": "Cold Ready"
  },
  {
    "id": "SR118",
    "name": "Tailored Chino Pants",
    "price": 2250,
    "stock": 17,
    "category": "discount",
    "gender": "Men",
    "image": "Image/Chino Pants.webp",
    "description": "Refined chino trousers that work from office to evening.",
    "sizes": [
      "30",
      "32",
      "34",
      "36"
    ],
    "badge": "Value"
  },
  {
    "id": "SR119",
    "name": "Executive Classic Suit",
    "price": 9800,
    "stock": 5,
    "category": "evening",
    "gender": "Men",
    "image": "Image/Classic Suit.webp",
    "description": "Formal suit with sharp lines, event-ready structure, and versatile styling.",
    "sizes": [
      "38",
      "40",
      "42"
    ],
    "badge": "Premium"
  }
];

function isMensProduct(product){
  return String(product.gender).toLowerCase() === "men";
}
function isWomensProduct(product){
  return String(product.gender).toLowerCase() === "women";
}
function sortProductsForDisplay(items){
  return [...items].sort((a,b) => {
    const g = String(a.gender).localeCompare(String(b.gender));
    return g || a.name.localeCompare(b.name);
  });
}

const STORAGE_KEYS = {
  stock: 'soroth_v2_stock',
  cart: 'soroth_v2_cart',
  orders: 'soroth_v2_orders',
  profile: 'soroth_v2_profile'
};

function getStockMap() {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEYS.stock) || '{}');
  const map = {};
  SOROTH_PRODUCTS.forEach(p => map[p.id] = typeof saved[p.id] === 'number' ? saved[p.id] : p.stock);
  return map;
}
function saveStockMap(map){ localStorage.setItem(STORAGE_KEYS.stock, JSON.stringify(map)); }
function getProductsWithLiveStock(){
  const stock = getStockMap();
  return SOROTH_PRODUCTS.map(p => ({...p, liveStock: stock[p.id] ?? p.stock}));
}
function getCart(){ return JSON.parse(localStorage.getItem(STORAGE_KEYS.cart) || '[]'); }
function saveCart(cart){ localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify(cart)); syncBadges(); }
function getOrders(){ return JSON.parse(localStorage.getItem(STORAGE_KEYS.orders) || '[]'); }
function saveOrders(orders){ localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify(orders)); }

function deleteOrder(orderId){
  const orders = getOrders().filter(o => o.id !== orderId);
  saveOrders(orders);
}
function resetStoreData(){
  localStorage.removeItem(STORAGE_KEYS.stock);
  localStorage.removeItem(STORAGE_KEYS.cart);
  localStorage.removeItem(STORAGE_KEYS.orders);
  syncBadges();
}

function getProfile(){
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.profile) || JSON.stringify({
    name: 'Soroth Customer',
    email: 'hello@soroth.com',
    phone: '+880 1XXXXXXXXX',
    address: 'Dhaka, Bangladesh'
  }));
}
function saveProfile(profile){ localStorage.setItem(STORAGE_KEYS.profile, JSON.stringify(profile)); }

function money(n){ return '৳' + Number(n).toLocaleString(); }
function syncBadges(){
  document.querySelectorAll('[data-cart-count]').forEach(el => el.textContent = getCart().reduce((s,i)=>s+i.quantity,0));
}
function findProduct(id){ return getProductsWithLiveStock().find(p => p.id === id); }

function addToCart(productId, quantity=1){
  const product = findProduct(productId);
  if (!product) return;
  if (product.liveStock <= 0){ alert('This item is currently out of stock.'); return; }
  const cart = getCart();
  const existing = cart.find(item => item.id === productId);
  const desiredQty = (existing?.quantity || 0) + quantity;
  if (desiredQty > product.liveStock){
    alert('Only ' + product.liveStock + ' item(s) available right now.');
    return;
  }
  if (existing) existing.quantity += quantity;
  else cart.push({id: product.id, quantity, size: product.sizes[0] || 'Standard'});
  saveCart(cart);
  alert(product.name + ' added to cart.');
}
function updateCartItem(id, quantity){
  const cart = getCart();
  const product = findProduct(id);
  const item = cart.find(i => i.id === id);
  if (!item || !product) return;
  item.quantity = Math.max(1, Math.min(quantity, product.liveStock));
  saveCart(cart);
}
function removeCartItem(id){
  saveCart(getCart().filter(i => i.id !== id));
}
function getCartDetailed(){
  return getCart().map(item => {
    const product = findProduct(item.id);
    return product ? ({...product, quantity:item.quantity, size:item.size}) : null;
  }).filter(Boolean);
}
function placeOrder(customer){
  const items = getCartDetailed();
  if (!items.length){ alert('Your cart is empty.'); return null; }
  const order = {
    id: 'SR' + Date.now().toString().slice(-8),
    createdAt: new Date().toISOString(),
    status: 'pending',
    customer,
    items: items.map(i => ({id:i.id, name:i.name, price:i.price, quantity:i.quantity, size:i.size, image:i.image})),
    subtotal: items.reduce((s, i) => s + i.price * i.quantity, 0),
    totalItems: items.reduce((s, i) => s + i.quantity, 0)
  };
  const orders = getOrders();
  orders.unshift(order);
  saveOrders(orders);
  saveCart([]);
  saveProfile(customer);
  return order;
}
function updateOrderStatus(orderId, nextStatus){
  const orders = getOrders();
  const order = orders.find(o => o.id === orderId);
  if (!order) return;
  if (order.status === nextStatus) return;
  if (nextStatus === 'confirmed' && order.status !== 'confirmed'){
    const stock = getStockMap();
    for (const item of order.items){
      const available = stock[item.id] ?? 0;
      if (available < item.quantity){
        alert('Not enough stock left to confirm ' + order.id + ' for ' + item.name + '.');
        return;
      }
    }
    for (const item of order.items){ stock[item.id] -= item.quantity; }
    saveStockMap(stock);
  }
  order.status = nextStatus;
  saveOrders(orders);
}
function renderProducts(targetId, filter='all', limit=null){
  const mount = document.getElementById(targetId);
  if (!mount) return;
  let items = getProductsWithLiveStock();
  const normalized = String(filter).toLowerCase();
  if (normalized === 'men') {
    items = items.filter(isMensProduct);
  } else if (normalized === 'women') {
    items = items.filter(isWomensProduct);
  } else if (normalized !== 'all') {
    items = items.filter(p => String(p.category).toLowerCase() === normalized);
  }
  items = sortProductsForDisplay(items);
  if (limit) items = items.slice(0, limit);
  mount.innerHTML = items.map(p => `
    <article class="product-card" id="${p.id}">
      <div class="product-image">
        <img src="${p.image}" alt="${p.name}">
        <span class="product-badge">${p.badge}</span>
        <span class="stock-badge">${p.liveStock} left</span>
      </div>
      <div class="product-body">
        <div class="muted small">${p.id} · ${p.gender} · ${p.category}</div>
        <h3>${p.name}</h3>
        <p class="muted">${p.description}</p>
        <div class="price-row">
          <div class="price">${money(p.price)}</div>
          <div class="muted small">${p.sizes.join(' / ')}</div>
        </div>
        <div class="product-actions">
          <button class="btn btn-soft" onclick="window.location.href='collections_page.html#${p.id}'">View</button>
          <button class="btn btn-primary" onclick="addToCart('${p.id}')">Add to Cart</button>
        </div>
      </div>
    </article>`).join('');
}
function renderCategories(targetId){
  const mount = document.getElementById(targetId);
  if (!mount) return;
  const cards = [
    {name:'Women Collection', file:'collections_page.html?view=women', image:'Image/soroth_green_gown.jpg', text:'Elegant festive, formal, and daily styles for a polished wardrobe.'},
    {name:'Men Collection', file:'collections_page.html?view=men', image:'Image/soroth_mens_polo.jpg', text:'Clean polos, shirts, and versatile essentials with modern styling.'},
  ];
  mount.innerHTML = cards.map(c => `
    <a href="${c.file}" class="category-card">
      <div class="category-thumb"><img src="${c.image}" alt="${c.name}"></div>
      <h3>${c.name}</h3>
      <p>${c.text}</p>
      <div class="meta"><span class="chip">Explore</span><span>→</span></div>
    </a>`).join('');
}
function setupFilters(buttonSelector, targetId){
  const buttons = document.querySelectorAll(buttonSelector);
  buttons.forEach(btn => btn.addEventListener('click', () => {
    buttons.forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    renderProducts(targetId, btn.dataset.filter || 'all');
  }));
}
document.addEventListener('DOMContentLoaded', syncBadges);
